# PROG5121 POE – QuickChat (Part 1, Part 2 and Part 3)

## Requirements
- JDK 21
- Apache Maven 3.9 or later
- NetBeans with Maven project support

## Open and run in NetBeans
1. Extract the ZIP file.
2. In NetBeans, select **File → Open Project**.
3. Select the `PROG5121_POE` folder (the folder containing `pom.xml`).
4. Allow Maven to download the project dependencies.
5. Right-click the project and select **Clean and Build**.
6. Run `com.mycompany.prog5121_poe.Main`.

## Run from a terminal
Open a terminal in the folder containing `pom.xml` and run:

```bash
mvn clean verify
mvn exec:java
```

## Part 3 functionality
- Maintains separate runtime collections for sent, disregarded and stored messages.
- Maintains message ID and message hash indexes.
- Displays sender and recipient information for stored messages.
- Displays the longest message across sent and stored messages.
- Searches messages by message ID and recipient.
- Deletes stored messages using their message hash.
- Displays a detailed stored-message report.
- Reads stored messages from and writes stored messages to `messages.json`.

## Unit tests
Run all tests with:

```bash
mvn --batch-mode clean verify
```

The build uses the Java 21 release level. Ensure JDK 21 and Maven are installed and available on your PATH. A successful local build and a successful GitHub Actions run should both be checked before submission.

The JUnit 5 tests cover login validation, message length and recipient validation, message sending/storing/disregarding, collection population, longest-message lookup, message ID and recipient searches, hash-based deletion, JSON persistence and report output.

## GitHub setup and submission
If this folder is not already a Git repository, run:

```bash
git init
git add .
git commit -m "Complete PROG5121 POE Part 3"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/PROG5121_POE.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If you already have a Git repository, do **not** run `git init` or add a second `origin`; instead use `git status`, `git add .`, `git commit -m "Improve Part 3 features and tests"`, and `git push`.

The workflow at `.github/workflows/Test.java.yml` runs `mvn --batch-mode clean test` on pushes and pull requests to `main` or `master`. Open the repository's **Actions** tab and confirm that the latest run succeeds before submitting.

## Submission checklist
- [ ] Open the extracted project in NetBeans.
- [ ] Run **Clean and Build** successfully.
- [ ] Run all JUnit tests successfully.
- [ ] Test each Part 3 menu feature manually, including JSON loading and deletion.
- [ ] Push the source code, tests, `pom.xml`, `messages.json`, README and workflow to GitHub.
- [ ] Confirm the GitHub Actions run is successful.
- [ ] Check that the GitHub repository contains the source, tests, `pom.xml`, `messages.json`, README and workflow (not only a ZIP file).
- [ ] Submit the project in the format and repository-link format required by the lecturer.

## Verification status
The project files and Maven XML configuration have been inspected. The full Maven/JUnit suite must still be run in an environment with Maven and the declared dependencies available; do not treat the project as test-passing until that run succeeds.

Do not commit passwords, access tokens or other credentials. Do not upload the Maven `target/` build directory.
