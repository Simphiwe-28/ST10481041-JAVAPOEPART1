package com.mycompany.prog5121_poe;

import com.google.gson.*;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/**
 * Represents a QuickChat message and manages the message collections used in Part 3.
 * Collections are populated at run time; no message data is hard-coded here.
 */
public class Message {
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();
    private static final List<String> messageIds = new ArrayList<>();
    private static int totalSent = 0;
    private static int created = 0;
    private static Path storageFile = Path.of("messages.json");

    private final String messageId;
    private final int messageNumber;
    private final String sender;
    private final String recipient;
    private final String text;
    private final String hash;

    public Message(String recipient, String text) {
        this("Unknown sender", recipient, text);
    }

    public Message(String sender, String recipient, String text) {
        this.messageId = String.format("%010d", 1_000_000_000L + new Random().nextInt(1_000_000_000));
        this.messageNumber = created++;
        this.sender = Objects.requireNonNullElse(sender, "Unknown sender");
        this.recipient = Objects.requireNonNullElse(recipient, "");
        this.text = Objects.requireNonNullElse(text, "");
        this.hash = createMessageHash();
    }

    public boolean checkMessageID() { return messageId.length() == 10; }

    public String checkRecipientCell() {
        return recipient.matches("^\\+\\d{10,13}$")
                ? "Cell phone number successfully captured."
                : "Cell phone number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
    }

    public static String checkMessageLength(String text) {
        return text != null && text.length() <= 250
                ? "Success"
                : "Please enter a message of 250 characters or fewer.";
    }

    public String createMessageHash() {
        String trimmed = text.trim();
        String[] words = trimmed.isEmpty() ? new String[]{"EMPTY"} : trimmed.split("\\s+");
        String first = words[0].replaceAll("[^A-Za-z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^A-Za-z0-9]", "");
        return (messageId.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }

    private Message(String id, String hash, String sender, String recipient, String text, int number) {
        this.messageId = id;
        this.hash = hash;
        this.sender = sender;
        this.recipient = recipient;
        this.text = text;
        this.messageNumber = number;
    }

    /** 1 = sent, 2 = disregarded, 3 = stored. */
    public String sentMessage(int choice) {
        switch (choice) {
            case 1 -> {
                sentMessages.add(this);
                totalSent++;
                addToIndexes(this);
                return "Message successfully sent";
            }
            case 2 -> {
                disregardedMessages.add(this);
                addToIndexes(this);
                return "Press 0 to delete the message";
            }
            case 3 -> {
                storedMessages.add(this);
                addToIndexes(this);
                saveStoredMessages();
                return "Message successfully stored";
            }
            default -> { return "Invalid option"; }
        }
    }

    public String sentMessage(Scanner in) {
        System.out.println("1) Send Message  2) Disregard Message  3) Store Message to send later");
        int choice;
        try { choice = Integer.parseInt(in.nextLine().trim()); }
        catch (NumberFormatException ex) { choice = -1; }
        return sentMessage(choice);
    }

    private static void addToIndexes(Message message) {
        messageHashes.add(message.hash);
        messageIds.add(message.messageId);
    }

    public static String printMessages() {
        StringBuilder result = new StringBuilder();
        for (Message message : sentMessages) result.append(message.details()).append(System.lineSeparator());
        return result.toString();
    }

    public static int returnTotalMessages() { return totalSent; }

    public String details() {
        return "Message ID: " + messageId + "\nMessage Hash: " + hash
                + "\nSender: " + sender + "\nRecipient: " + recipient
                + "\nMessage: " + text + "\n";
    }

    public static List<Message> getSentMessages() { return Collections.unmodifiableList(sentMessages); }
    public static List<Message> getDisregardedMessages() { return Collections.unmodifiableList(disregardedMessages); }
    public static List<Message> getStoredMessages() { return Collections.unmodifiableList(storedMessages); }
    public static List<String> getMessageHashes() { return Collections.unmodifiableList(messageHashes); }
    public static List<String> getMessageIds() { return Collections.unmodifiableList(messageIds); }

    public static String displayStoredSenderRecipients() {
        if (storedMessages.isEmpty()) return "No stored messages found.";
        StringBuilder out = new StringBuilder();
        for (Message m : storedMessages) out.append("Sender: ").append(m.sender)
                .append(" | Recipient: ").append(m.recipient).append('\n');
        return out.toString();
    }

    /** Returns the longest message across sent and stored messages. */
    public static Optional<Message> getLongestMessage() {
        return java.util.stream.Stream.concat(sentMessages.stream(), storedMessages.stream())
                .max(Comparator.comparingInt(m -> m.text.length()));
    }

    /** Retained for compatibility with earlier Part 3 code and tests. */
    public static Optional<Message> getLongestStoredMessage() {
        return getLongestMessage();
    }

    /** Searches all message statuses by their unique message ID. */
    public static Optional<Message> searchByMessageId(String id) {
        if (id == null) return Optional.empty();
        return java.util.stream.Stream.of(sentMessages, disregardedMessages, storedMessages)
                .flatMap(Collection::stream)
                .filter(m -> m.messageId.equals(id))
                .findFirst();
    }

    public static List<Message> searchByRecipient(String recipient) {
        List<Message> matches = new ArrayList<>();
        if (recipient == null || recipient.isBlank()) return matches;
        for (Message m : sentMessages) if (m.recipient.equals(recipient)) matches.add(m);
        for (Message m : storedMessages) if (m.recipient.equals(recipient)) matches.add(m);
        return matches;
    }

    public static boolean deleteStoredMessageByHash(String hash) {
        if (hash == null || hash.isBlank()) return false;
        Iterator<Message> iterator = storedMessages.iterator();
        while (iterator.hasNext()) {
            Message m = iterator.next();
            if (m.hash.equalsIgnoreCase(hash)) {
                iterator.remove();
                messageHashes.remove(m.hash);
                messageIds.remove(m.messageId);
                saveStoredMessages();
                return true;
            }
        }
        return false;
    }

    public static String storedMessagesReport() {
        if (storedMessages.isEmpty()) return "No stored messages found.";
        StringBuilder out = new StringBuilder("STORED MESSAGES REPORT\n======================\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            out.append("Stored message ").append(i + 1).append('\n')
               .append(storedMessages.get(i).details()).append("----------------------\n");
        }
        return out.toString();
    }

    /** Saves stored messages as JSON in the project working directory. */
    public static void setStorageFile(Path file) {
        storageFile = Objects.requireNonNull(file, "Storage file cannot be null");
    }

    public static void saveStoredMessages() {
        JsonArray array = new JsonArray();
        for (Message m : storedMessages) {
            JsonObject obj = new JsonObject();
            obj.addProperty("messageId", m.messageId);
            obj.addProperty("messageHash", m.hash);
            obj.addProperty("sender", m.sender);
            obj.addProperty("recipient", m.recipient);
            obj.addProperty("message", m.text);
            array.add(obj);
        }
        try {
            Path parent = storageFile.toAbsolutePath().getParent();
            if (parent != null) Files.createDirectories(parent);
            Files.writeString(storageFile, new GsonBuilder().setPrettyPrinting().create().toJson(array));
        } catch (IOException ex) {
            System.err.println("Could not write messages.json: " + ex.getMessage());
        }
    }

    /** Reads messages.json and places its contents into the stored-message and index collections. */
    public static int loadStoredMessages() {
        return loadStoredMessages(storageFile);
    }

    public static int loadStoredMessages(Path file) {
        if (!Files.exists(file)) return 0;
        try {
            JsonElement root = JsonParser.parseString(Files.readString(file));
            if (!root.isJsonArray()) throw new JsonParseException("Expected a JSON array.");
            // Remove the previous stored-message index entries before reloading.
            for (Message existing : storedMessages) {
                messageHashes.remove(existing.hash);
                messageIds.remove(existing.messageId);
            }
            storedMessages.clear();
            int loaded = 0;
            for (JsonElement element : root.getAsJsonArray()) {
                JsonObject obj = element.getAsJsonObject();
                String recipient = getJsonString(obj, "recipient");
                String body = getJsonString(obj, "message");
                String sender = getJsonString(obj, "sender");
                String id = getJsonString(obj, "messageId");
                String hash = getJsonString(obj, "messageHash");
                if (id.isBlank()) id = String.format("%010d", 1_000_000_000L + new Random().nextInt(1_000_000_000));
                if (hash.isBlank()) {
                    Message generated = new Message(sender, recipient, body);
                    id = generated.messageId;
                    hash = generated.hash;
                }
                int number = 0;
                String[] hashParts = hash.split(":");
                if (hashParts.length > 1) {
                    try { number = Integer.parseInt(hashParts[1]); } catch (NumberFormatException ignored) { }
                }
                Message message = new Message(id, hash, sender.isBlank() ? "Unknown sender" : sender,
                        recipient, body, number);
                storedMessages.add(message);
                messageIds.add(message.messageId);
                messageHashes.add(message.hash);
                created = Math.max(created, number + 1);
                loaded++;
            }
            return loaded;
        } catch (IOException | JsonParseException | IllegalStateException ex) {
            System.err.println("Could not read messages.json: " + ex.getMessage());
            return 0;
        }
    }

    private static String getJsonString(JsonObject obj, String key) {
        JsonElement value = obj.get(key);
        return value == null || value.isJsonNull() ? "" : value.getAsString();
    }

    public static void resetAll() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIds.clear();
        totalSent = 0;
        created = 0;
        storageFile = Path.of("messages.json");
    }

    public String getMessageID() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getHash() { return hash; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getText() { return text; }
}
