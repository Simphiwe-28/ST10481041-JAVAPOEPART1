package com.mycompany.prog5121_poe;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class QuickChat {
    public static void main(String[] args) { run(new Scanner(System.in)); }

    public static void run(Scanner in) {
        System.out.println("Welcome to QuickChat.");
        int loaded = Message.loadStoredMessages();
        System.out.println(loaded + " stored message(s) loaded from messages.json.");
        System.out.print("How many messages do you wish to enter? ");
        int max = readInt(in, 0);
        int entered = 0;

        while (true) {
            System.out.println("\nMAIN MENU");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Stored Messages");
            System.out.println("4) Quit");
            String option = in.nextLine().trim();
            switch (option) {
                case "1" -> {
                    if (entered >= max) {
                        System.out.println("You have reached your limit of " + max + " messages.");
                        continue;
                    }
                    System.out.print("Recipient cell (+countrycode...): ");
                    String recipient = in.nextLine().trim();
                    Message probe = new Message(Auth.getCurrentUserCell(), recipient, "x");
                    String cellResult = probe.checkRecipientCell();
                    System.out.println(cellResult);
                    if (!cellResult.startsWith("Cell phone number successfully")) continue;

                    System.out.print("Message (max 250 chars): ");
                    String text = in.nextLine();
                    String lengthResult = Message.checkMessageLength(text);
                    if (!lengthResult.equals("Success")) {
                        System.out.println(lengthResult);
                        continue;
                    }
                    Message message = new Message(Auth.getCurrentUserCell(), recipient, text);
                    System.out.println(message.sentMessage(in));
                    System.out.println(message.details());
                    entered++;
                }
                case "2" -> System.out.println(Message.printMessages().isBlank()
                        ? "No sent messages yet." : Message.printMessages());
                case "3" -> storedMessagesMenu(in);
                case "4" -> {
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    return;
                }
                default -> System.out.println("Please choose 1, 2, 3 or 4.");
            }
        }
    }

    private static void storedMessagesMenu(Scanner in) {
        while (true) {
            System.out.println("\nSTORED MESSAGES");
            System.out.println("1) Display senders and recipients");
            System.out.println("2) Display details for the longest message");
            System.out.println("3) Search by message ID");
            System.out.println("4) Search by recipient");
            System.out.println("5) Delete using message hash");
            System.out.println("6) Display full stored-message report");
            System.out.println("7) Return to main menu");
            String choice = in.nextLine().trim();
            switch (choice) {
                case "1" -> System.out.println(Message.displayStoredSenderRecipients());
                case "2" -> {
                    Optional<Message> longest = Message.getLongestMessage();
                    System.out.println(longest.map(Message::details).orElse("No messages found."));
                }
                case "3" -> {
                    System.out.print("Enter message ID: ");
                    Optional<Message> found = Message.searchByMessageId(in.nextLine().trim());
                    System.out.println(found.map(Message::details).orElse("Message ID not found."));
                }
                case "4" -> {
                    System.out.print("Enter recipient number: ");
                    List<Message> matches = Message.searchByRecipient(in.nextLine().trim());
                    if (matches.isEmpty()) System.out.println("No messages found for this recipient.");
                    else matches.forEach(m -> System.out.println(m.details()));
                }
                case "5" -> {
                    System.out.print("Enter message hash: ");
                    System.out.println(Message.deleteStoredMessageByHash(in.nextLine().trim())
                            ? "Message successfully deleted." : "Message hash not found.");
                }
                case "6" -> System.out.println(Message.storedMessagesReport());
                case "7" -> { return; }
                default -> System.out.println("Please choose an option from 1 to 7.");
            }
        }
    }

    private static int readInt(Scanner in, int fallback) {
        try { return Integer.parseInt(in.nextLine().trim()); }
        catch (NumberFormatException ex) { return fallback; }
    }
}
