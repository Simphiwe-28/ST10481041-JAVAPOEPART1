package com.mycompany.prog5121_poe;

import java.nio.file.Path;
import org.junit.jupiter.api.io.TempDir;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class Part3MessageTest {
    @TempDir Path tempDir;

    @BeforeEach
    void reset() {
        Message.resetAll();
        Message.setStorageFile(tempDir.resolve("messages.json"));
    }

    @Test
    void arraysArePopulatedForEachMessageStatus() {
        Message sent = new Message("Sender A", "+27834557896", "Did you get the cake?");
        Message disregarded = new Message("Sender A", "+278358884567", "Yoh");
        Message stored = new Message("Sender B", "+27838884567", "Ok, I am leaving without you.");
        sent.sentMessage(1);
        disregarded.sentMessage(2);
        stored.sentMessage(3);

        assertEquals(1, Message.getSentMessages().size());
        assertEquals(1, Message.getDisregardedMessages().size());
        assertEquals(1, Message.getStoredMessages().size());
        assertEquals(3, Message.getMessageHashes().size());
        assertEquals(3, Message.getMessageIds().size());
    }

    @Test
    void displaysLongestStoredMessage() {
        Message shortMessage = new Message("Sender", "+27834557896", "Hi");
        Message longMessage = new Message("Sender", "+27834557896", "Where are you? You are late! I have asked you to be on time.");
        shortMessage.sentMessage(3);
        longMessage.sentMessage(3);

        assertEquals(longMessage.getText(), Message.getLongestStoredMessage().orElseThrow().getText());
    }

    @Test
    void searchesStoredMessageById() {
        Message message = new Message("Sender", "+27834557896", "It is dinner time!");
        message.sentMessage(3);

        assertEquals(message.getRecipient(), Message.searchByMessageId(message.getMessageID()).orElseThrow().getRecipient());
        assertTrue(Message.searchByMessageId("not-an-id").isEmpty());
    }

    @Test
    void searchesSentAndStoredMessagesByRecipient() {
        Message sent = new Message("Sender", "+27838884567", "Sent message");
        Message stored = new Message("Sender", "+27838884567", "Stored message");
        sent.sentMessage(1);
        stored.sentMessage(3);

        List<Message> found = Message.searchByRecipient("+27838884567");
        assertEquals(2, found.size());
    }

    @Test
    void deletesStoredMessageUsingHash() {
        Message message = new Message("Sender", "+27834557896", "Delete this message");
        message.sentMessage(3);

        assertTrue(Message.deleteStoredMessageByHash(message.getHash()));
        assertTrue(Message.getStoredMessages().isEmpty());
        assertFalse(Message.deleteStoredMessageByHash(message.getHash()));
    }

    @Test
    void reportContainsAllStoredMessageDetails() {
        Message message = new Message("Sender", "+27834557896", "Report test message");
        message.sentMessage(3);

        String report = Message.storedMessagesReport();
        assertTrue(report.contains(message.getMessageID()));
        assertTrue(report.contains(message.getHash()));
        assertTrue(report.contains(message.getRecipient()));
        assertTrue(report.contains(message.getText()));
        assertTrue(report.contains(message.getSender()));
    }

    @Test
    void assignmentTestDataPopulatesTheRequiredCollections() {
        Message message1 = new Message("Current user", "+27834557896", "Did you get the cake?");
        Message message2 = new Message("Current user", "+27838884567",
                "Where are you? You are late! I have asked you to be on time.");
        Message message3 = new Message("Current user", "+27834484567", "Yohoooo, I am at your gate.");
        Message message4 = new Message("0838884567", "+27834557896", "It is dinner time!");
        Message message5 = new Message("Current user", "+27838884567", "Ok, I am leaving without you.");

        message1.sentMessage(1);
        message2.sentMessage(3);
        message3.sentMessage(2);
        message4.sentMessage(1);
        message5.sentMessage(3);

        assertEquals(2, Message.getSentMessages().size());
        assertEquals(1, Message.getDisregardedMessages().size());
        assertEquals(2, Message.getStoredMessages().size());
        assertEquals(message2.getText(), Message.getLongestStoredMessage().orElseThrow().getText());
        assertEquals(2, Message.searchByRecipient("+27838884567").size());
        assertEquals(message4.getText(),
                Message.searchByMessageId(message4.getMessageID()).orElseThrow().getText());
    }

    @Test
    void loadingJsonTwiceDoesNotDuplicateStoredMessagesOrIndexes() throws Exception {
        Message original = new Message("Sender", "+27834557896", "Persisted message");
        original.sentMessage(3);
        Path file = tempDir.resolve("messages.json");

        Message.resetAll();
        Message.setStorageFile(file);
        assertEquals(1, Message.loadStoredMessages(file));
        assertEquals(1, Message.loadStoredMessages(file));

        assertEquals(1, Message.getStoredMessages().size());
        assertEquals(1, Message.getMessageHashes().size());
        assertEquals(1, Message.getMessageIds().size());
    }


    @Test
    void longestMessageIncludesSentAndStoredMessages() {
        Message shortSent = new Message("Sender", "+27834557896", "Short sent message");
        Message longSent = new Message("Sender", "+27834557896", "This is the longest message across all message statuses");
        Message stored = new Message("Sender", "+27834557896", "Stored message");
        shortSent.sentMessage(1);
        longSent.sentMessage(1);
        stored.sentMessage(3);

        assertEquals(longSent.getMessageID(), Message.getLongestMessage().orElseThrow().getMessageID());
    }

    @Test
    void searchesDisregardedMessageById() {
        Message disregarded = new Message("Sender", "+27834557896", "Do not send this");
        disregarded.sentMessage(2);

        assertEquals(disregarded.getMessageID(),
                Message.searchByMessageId(disregarded.getMessageID()).orElseThrow().getMessageID());
        assertTrue(Message.searchByMessageId(null).isEmpty());
    }

    @Test
    void rejectsMessagesLongerThan250Characters() {
        assertEquals("Success", Message.checkMessageLength("a".repeat(250)));
        assertNotEquals("Success", Message.checkMessageLength("a".repeat(251)));
    }

    @Test
    void deletingWithNullOrBlankHashDoesNotCrash() {
        Message message = new Message("Sender", "+27834557896", "Keep this message");
        message.sentMessage(3);

        assertFalse(Message.deleteStoredMessageByHash(null));
        assertFalse(Message.deleteStoredMessageByHash("   "));
        assertEquals(1, Message.getStoredMessages().size());
    }

    @Test
    void searchingWithNullOrBlankRecipientReturnsNoResults() {
        assertTrue(Message.searchByRecipient(null).isEmpty());
        assertTrue(Message.searchByRecipient("   ").isEmpty());
    }

    @Test
    void invalidMessageStatusDoesNotChangeCollections() {
        Message message = new Message("Sender", "+27834557896", "Status test");

        assertEquals("Invalid option", message.sentMessage(9));
        assertTrue(Message.getSentMessages().isEmpty());
        assertTrue(Message.getDisregardedMessages().isEmpty());
        assertTrue(Message.getStoredMessages().isEmpty());
        assertTrue(Message.getMessageIds().isEmpty());
        assertTrue(Message.getMessageHashes().isEmpty());
    }

    @Test
    void readsStoredMessagesFromJsonFile() {
        int count = Message.loadStoredMessages(Path.of("messages.json"));
        assertTrue(count >= 0);
        assertEquals(count, Message.getStoredMessages().size());
    }
}
