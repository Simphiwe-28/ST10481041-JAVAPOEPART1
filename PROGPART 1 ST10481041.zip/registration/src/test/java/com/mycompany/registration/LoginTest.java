
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

import org.junit.jupiter.api.Test;


import com.mycompany.registration.Login;

/**
 *
 * @author Student
 */
public class LoginTest {

    @Test
    void testValidUsername() {
        Login login = new Login("Kyle", "Smith");

        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    void testUsernameWithoutUnderscore() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkUserName("Kyle"));
    }

    @Test
    void testUsernameTooLong() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkUserName("john_s_"));
    }

    @Test
    void testValidPassword() {
        Login login = new Login("Kyle", "Smith");

        assertTrue(login.checkpasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    void testPasswordTooShort() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkpasswordComplexity("Pass1!"));
    }

    @Test
    void testPasswordWithoutCapitalLetter() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkpasswordComplexity("password1!"));
    }

    @Test
    void testPasswordWithoutNumber() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkpasswordComplexity("Password!"));
    }

    @Test
    void testPasswordWithoutSpecialCharacter() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkpasswordComplexity("Password1"));
    }

    @Test
    void testValidCellPhoneNumber() {
        Login login = new Login("Kyle", "Smith");

        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    void testInvalidCellPhoneNumber() {
        Login login = new Login("Kyle", "Smith");

        assertFalse(login.checkCellPhoneNumber("0123456789"));
    }

    @Test
    void testSuccessfulRegistration() {
        Login login = new Login("Kyle", "Smith");

        String result = login.registerUser(
                "kyl_1",
                "Ch&&sec@ke99!",
                "+27838968976",
                "kyle",
                "Smith"
        );

        assertEquals("Registration successful.", result);
    }

    @Test
    void testFailedRegistrationWithInvalidUsername() {
        Login login = new Login("John", "Smith");

        String result = login.registerUser(
                "kyle",
                "Ch&&sec@ke99!",
                "+278389968976",
                "Kyle",
                "Smith"
        );

        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    void testFailedRegistrationWithInvalidPassword() {
        Login login = new Login("John", "Smith");

        String result = login.registerUser(
                "jo_n",
                "password",
                "+27123456789",
                "John",
                "Smith"
        );

        assertTrue(result.contains("password is not correctly formatted"));
    }

    @Test
    void testFailedRegistrationWithInvalidPhoneNumber() {
        Login login = new Login("John", "Smith");

        String result = login.registerUser(
                "jo_n",
                "Password1!",
                "0123456789",
                "John",
                "Smith"
        );

        assertTrue(result.contains("cell phone number"));
    }

    @Test
    void testSuccessfulLogin() {
        Login login = new Login("Kyle", "Smith");

        login.registerUser(
                "kyl_!",
                "Ch&&sec@ke99!",
                "+2783896876",
                "Kyle",
                "Smith"
        );

        assertTrue(login.loginUser("jo_n", "Password1!"));
    }

    @Test
    void testFailedLoginWrongUsername() {
        Login login = new Login("John", "Smith");

        login.registerUser(
                "jo_n",
                "Password1!",
                "+27123456789",
                "John",
                "Smith"
        );

        assertFalse(login.loginUser("wrong", "Password1!"));
    }

    @Test
    void testFailedLoginWrongPassword() {
        Login login = new Login("John", "Smith");

        login.registerUser(
                "jo_n",
                "Password1!",
                "+27123456789",
                "John",
                "Smith"
        );

        assertFalse(login.loginUser("jo_n", "WrongPassword1!"));
    }

    private void assertTrue(boolean checkCellPhoneNumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean checkCellPhoneNumber) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertEquals(String registration_successful, String result) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
