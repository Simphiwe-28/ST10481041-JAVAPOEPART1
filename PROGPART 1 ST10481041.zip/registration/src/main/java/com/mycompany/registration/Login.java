/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

/**
 *
 * @author Student
 */
public class Login {
    // declaration of variable using private
    private String firstName;
    private static String lastName;
    private static String cellPhoneNumber;
    // variables for checking login
    private String storedUserName;
    private String storedPassword;
    
    public Login(String fname,String lname){
        this.firstName=fname;
        this .lastName=lname;
    }
    // boolean to check username
    public boolean checkUserName(String username){
        return username.contains("_") && username.length()<=5;
    }
    //boolean to check the password
public boolean checkpasswordComplexity(String password) {
    boolean hasNumber = false;
    boolean hasCap = false;
    boolean hasSpecial = false;

    if (password == null || password.length() < 8) {
        return false;
    }
//the use of for loop to check the password
    for (int i = 0; i < password.length(); i++) {
        char current = password.charAt(i);

        if (Character.isUpperCase(current)) {
            hasCap = true;
        }

        if (Character.isDigit(current)) {
            hasNumber = true;
        }

        if (!Character.isLetterOrDigit(current)) {
            hasSpecial = true;
        }
    }

    return hasNumber && hasCap && hasSpecial;
}
// boolean to check cellphone number
    public boolean checkCellPhoneNumber(String cellphonenumber){
        // regex for internationl number(e.g. +27xxxxxxxxx)
        String regex="^\\+\\d{11,13}$";
        return cellphonenumber.matches(regex);
    }
    // 
    public String registerUser(String username,String Password,String cellphonenumber,String fname,String lname){
        StringBuilder message= new StringBuilder();
        this.firstName=fname;
        this.lastName=lname;
        
        // the use of if statement to check the username and message append
        if(!checkUserName(username)){
            return"Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length"; 
        }
        message.append("username successfully captured.\n");
        
        if(!checkpasswordComplexity(Password)){
            return"Password is not correctly formatted;(please ensure that the password contains at least eight chararcters,a capital letter and special character.)";
        }
        message.append("Password successfully captured.\n");
        
        if (!checkCellPhoneNumber(cellphonenumber)){
            return"cell phone number incorretly formatted or does not contain international code.";
        }
        message.append("cellphone number successfully added.\n");
        
        this.storedUserName=username;
        this.storedPassword=Password;
        this.cellPhoneNumber=cellphonenumber;
        System.out.println(message.toString());
        
        return "Registration successful.";
        
        
    }
    // boolean to store and display the user information
    public boolean loginUser(String Username,String password){
        return Username.equals(this.storedUserName) && password.equals(this.storedPassword);
    }
    // the login status wheather to welcome the user or reenter the password
    public String returnLoginStatus(String userName,String password){
        if(loginUser(userName,password)){
            return"Welcome" + this.firstName +""+this.lastName +", it is grat toee you again";
        }else{
            return "username or Password incorrect, please try again";
        }
    }
}
