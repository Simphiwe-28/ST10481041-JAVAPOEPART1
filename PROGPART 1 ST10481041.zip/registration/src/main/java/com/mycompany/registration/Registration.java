/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Registration {
    //DECLARATION OF VARIABLES
       private static String firstName;
       private static String lastName;
       private static String Username;
       private static String password;
       private static String cellphonenumber;
       
       public static void setfirtName(String fname){
           firstName=fname;
       }
       public static String getFirstName(){
           return firstName;
       }
       public static void setlastname(String lname){
           lastName=lname;
       }
       public static String getlastname(){
           return lastName;
       }
       public static void setUserName(String username){
           Username=username;
       }
       public static String getuserName(){
           return Username;
       }
       public static void setcallnumber (String cellphonenum){
           cellphonenumber=cellphonenum;
       }
       public static String  getcellnumber(){
           return cellphonenumber;
       }
       public static void setpassword(String password){
           password=password;
       }
       public static String getpassword(){
           return password;
       }
    public static void main(String[] args) {
        // SCANNER USER FOR INPUT and rgistration for user
        
        try(Scanner myInput=new Scanner(System.in)){
            Login login= new Login(firstName,lastName);
            
            System.out.println("Registration");
            
            System.out.print("Please enter your first name:");
            firstName=myInput.nextLine();
            
            System.out.print("Please enter your last name:");
            lastName=myInput.nextLine();
            
            System.out.print("Please enter username(less than 5 characters and must contain an underscore");
            Username=myInput.nextLine();
            
            System.out.print("Please create a password(at least 8 char, 1 Capital letter, 1 number,1 special char");
            password=myInput.nextLine();
            
            String regStatus=login.registerUser(Username,password,cellphonenumber,firstName,lastName);
            System.out.println(regStatus);
            // IF STATEMENT OF THE REGISTRATION
            
            if (regStatus.equals("Registration successful")){
                System.out.println(regStatus);
                
                System.out.print("Enter the userName you created");
                String loginUser=myInput.nextLine();
                
                System.out.print("Enter the password you created");
                String loginPass=myInput.nextLine();
                
                String loginStatus=login.returnLoginStatus(loginUser,loginPass);
                System.out.println(loginStatus);
            }
            
        }
    }
}
