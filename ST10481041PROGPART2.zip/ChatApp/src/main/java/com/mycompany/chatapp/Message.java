/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;
import org.json.simple.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Message {
    
   
    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;

    private static int totalMessages = 0;
    private static final Random rand = new Random();

    public Message(String recipient, String messageText) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    // Generate a 10-digit random message ID
    public String generateMessageID() {
        return String.format("%010d", rand.nextInt(1_000_000_000));
    }

    // Check message ID is not more than 10 chars
    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    // Check recipient cell format
    public boolean checkRecipientCell() {
        String regex = "^\\+\\d{1,3}\\d{7,10}$";
        return recipient.matches(regex);
    }

    // Check message length <= 250
    public boolean checkMessageLength() {
        if (messageText.length() > 250) {
            int overBy = messageText.length() - 250;
            System.out.println("Message exceeds 250 characters by " + overBy + "; please reduce the size.");
            return false;
        }
        return true;
    }

    // Create Message Hash: first 2 digits of ID : message number : FIRSTLAST (uppercase)
    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord  = words.length > 1 ? words[words.length - 1] : firstWord;

        String firstTwo = messageID.substring(0, 2);
        return (firstTwo + ":" + totalMessages + ":" + firstWord + lastWord).toUpperCase();
    }

    // Ask the user to Send / Store / Disregard
    public String sentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose an action:");
        System.out.println("1) Send Message");
        System.out.println("2) Store Message");
        System.out.println("3) Disregard Message");
        System.out.print("Enter choice (1-3): ");

        int choice;
        try {
            choice = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            return "No action taken.";
        }

        switch (choice) {
            case 1:
                totalMessages++;
                return "Message successfully sent.";
            case 2:
                storeMessage();
                totalMessages++;
                return "Message successfully stored.";
            case 3:
                return "Press 0 to delete the message.";
            default:
                return "No action taken.";
        }
    }

    // Print message details
    public String printMessageDetails() {
        return "\nMessage ID: " + messageID +
               "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient +
               "\nMessage: " + messageText;
    }

    // Return total messages sent
    public static int returnTotalMessages() {
        return totalMessages;
    }

    // Store message to JSON file
    @SuppressWarnings("unchecked")
    public void storeMessage() {
        JSONObject msgObj = new JSONObject();
        msgObj.put("MessageID", messageID);
        msgObj.put("Recipient", recipient);
        msgObj.put("Message", messageText);
        msgObj.put("Hash", messageHash);

        try (FileWriter file = new FileWriter("stored_messages.json", true)) {
            file.write(msgObj.toJSONString());
            file.write(System.lineSeparator());
        } catch (IOException e) {
            System.out.println("Error writing JSON file.");
        }
    }
}
