/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatApp {

    public static void main(String[] args) {


       
        Scanner scanner = new Scanner(System.in);

        // ---------- Registration ----------
        System.out.println("Register - Enter username:");
        String username = scanner.nextLine();

        System.out.println("Enter password:");
        String password = scanner.nextLine();

        System.out.println("Enter cell number:");
        String cellNumber = scanner.nextLine();

        Login login = new Login(username, password, cellNumber);
        System.out.println(login.registerUser());

        // ---------- Login ----------
        System.out.println("\nLogin - Enter username:");
        String inputUser = scanner.nextLine();

        System.out.println("Enter password:");
        String inputPass = scanner.nextLine();

        boolean isLoggedIn = login.loginUser(inputUser, inputPass);

        System.out.println("Enter first name:");
        String firstName = scanner.nextLine();

        System.out.println("Enter last name:");
        String lastName = scanner.nextLine();

        System.out.println(login.returnLoginStatus(firstName, lastName, isLoggedIn));

        if (!isLoggedIn) {
            scanner.close();
            return;
        }

        // ---------- Main Menu ----------
        System.out.println("\nWelcome to QuickChat.");
        boolean running = true;

        while (running) {
            System.out.println("\nChoose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show Recently Sent Messages");
            System.out.println("3) Quit");
            System.out.print("Enter choice: ");

            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    System.out.println("How many messages to send?");
                    int numMessages;
                    try {
                        numMessages = Integer.parseInt(scanner.nextLine().trim());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid number.");
                        break;
                    }

                    for (int i = 0; i < numMessages; i++) {
                        System.out.println("\nMessage " + (i + 1) + " of " + numMessages);

                        System.out.println("Enter recipient cell number:");
                        String recipient = scanner.nextLine();

                        System.out.println("Enter message (max 250 chars):");
                        String messageText = scanner.nextLine();

                        Message msg = new Message(recipient, messageText);

                        // Validate recipient
                        if (!msg.checkRecipientCell()) {
                            System.out.println("Cell phone number is incorrectly formatted or does not contain an international code.");
                            i--; // retry this message
                            continue;
                        }

                        // Validate length
                        if (!msg.checkMessageLength()) {
                            i--; // retry this message
                            continue;
                        }

                        // Ask Send / Store / Disregard
                        System.out.println(msg.sentMessage());

                        // Show full details
                        System.out.println(msg.printMessageDetails());
                    }

                    System.out.println("\nTotal messages sent: " + Message.returnTotalMessages());
                    break;

                case "2":
                    System.out.println("Coming Soon.");
                    break;

                case "3":
                    System.out.println("Thank you for using QuickChat.");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }

        scanner.close();
    }
}  
     
    

